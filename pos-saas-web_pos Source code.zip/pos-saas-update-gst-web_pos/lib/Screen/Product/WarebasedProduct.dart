import 'package:flutter/material.dart';

class WarehouseBasedProductModel {
  late String productName;
  late String productID;

  WarehouseBasedProductModel(
    this.productName,
    this.productID,
  );
}
