// String currency = localCurrency;
String currency = '';

// String localCurrency = 'Tsh';

// List<String> items = [
//   'Tsh (TZ Shillings)',
//   '\$ (US Dollar)',
// ];
