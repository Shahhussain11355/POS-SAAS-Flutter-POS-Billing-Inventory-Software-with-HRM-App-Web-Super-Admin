package com.maantheme.salespro_saas_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
